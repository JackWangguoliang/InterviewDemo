package com.wgl.demo.domain;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.util.List;

// 标识此类为Spring的配置类,也就是Spring容器的组件,只有作为Spring的组件才能使用@ConfigurationPropertie进行配置文件和实体类之间的绑定功能
@Configuration
// 将coffer下级的key与实体类进行映射绑定,并为其注入属性值
@ConfigurationProperties(prefix = "city")
// 该类省略了set/get方法
public class City {
    // List集合
    private List<Weather> weather;

    @Override
    public String toString() {
        return "City{" +
                "weather=" + weather +
                '}';
    }
}
