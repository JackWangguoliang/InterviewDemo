package com.wgl.demo.domain;

public class Weather {
    private String location;
    private String temp;
    private String wind;

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getTemp() {
        return temp;
    }

    public void setTemp(String temp) {
        this.temp = temp;
    }

    public String getWind() {
        return wind;
    }

    public void setWind(String wind) {
        this.wind = wind;
    }

    @Override
    public String toString() {
        return "Weather{" +
                "location='" + location + '\'' +
                ", temp='" + temp + '\'' +
                ", wind='" + wind + '\'' +
                '}';
    }
}
