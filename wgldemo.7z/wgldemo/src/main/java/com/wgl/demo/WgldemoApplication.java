package com.wgl.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WgldemoApplication {
    public static void main(String[] args) {
        SpringApplication.run(WgldemoApplication.class, args);
    }
}
