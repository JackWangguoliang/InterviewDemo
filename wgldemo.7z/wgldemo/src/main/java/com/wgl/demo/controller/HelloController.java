package com.wgl.demo.controller;

import com.wgl.demo.domain.City;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloController {
    @Autowired
    City city;
    @RequestMapping("/getWeather")
    public String getWeather(){
        return city.toString();
    }
}
