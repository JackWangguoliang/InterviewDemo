package com.wgl.demo;


import com.wgl.demo.domain.City;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ApplicationContext;

@SpringBootTest
class WgldemoApplicationTests {

    @Autowired
    private ApplicationContext ioc;

    @Autowired
    private City city;

    @Test
    public void springbootTest(){
        System.out.println(city);
    }

}
